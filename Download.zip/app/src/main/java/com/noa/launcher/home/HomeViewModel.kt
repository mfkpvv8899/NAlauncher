package com.noa.launcher.home

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.noa.launcher.drawer.AppInfo
import com.noa.launcher.drawer.AppRepository
import com.noa.launcher.settings.NoaPrefs
import com.noa.launcher.settings.UiPrefs
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.launch

class HomeViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = AppRepository(app)
    private val allApps = MutableStateFlow<List<AppInfo>>(emptyList())

    /** Transparência/blur escolhidos nas configurações, atualizados ao vivo. */
    val ui: StateFlow<UiPrefs> = NoaPrefs.uiFlow(app)
        .stateIn(viewModelScope, SharingStarted.Eagerly, NoaPrefs.readUi(app))

    val query = MutableStateFlow("")
    val drawerOpen = MutableStateFlow(false)

    /** Lista filtrada pela busca (apps; contatos/web entram na próxima etapa). */
    val apps: StateFlow<List<AppInfo>> = combine(allApps, query) { list, q ->
        if (q.isBlank()) list else list.filter { it.label.contains(q, ignoreCase = true) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    /** Dock: primeiros 4 apps por padrão (troque por favoritos persistidos depois). */
    val dock: StateFlow<List<AppInfo>> = allApps
        .combine(MutableStateFlow(Unit)) { l, _ -> l.take(4) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    init { refresh() }

    fun refresh() = viewModelScope.launch { allApps.value = repo.loadApps() }
    fun launch(app: AppInfo) { repo.launch(app); closeDrawer() }
    fun openDrawer() { drawerOpen.value = true }
    fun closeDrawer() { drawerOpen.value = false; query.value = "" }
}
