package com.noa.launcher.settings

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow

/** Estado de UI derivado das preferências (imutável, observável via Flow). */
data class UiPrefs(
    val transparentMode: Boolean = false, // "Tudo transparente"
    val transparency: Float = 0.7f,       // 0 = visível (padrão glass) .. 1 = totalmente transparente
    val blur: Float = 0.6f                // 0 = sem blur .. 1 = blur máximo (API 31+)
) {
    /** Converte o alpha base de uma superfície "glass" no alpha final conforme o nível escolhido. */
    fun glass(base: Float): Float = if (transparentMode) base * (1f - transparency) else base

    /** Raio do blur-behind da janela, em px. */
    val blurRadiusPx: Int get() = (blur * 150f).toInt()
}

/** Preferências compartilhadas entre o launcher, as configurações e o WallpaperService. */
object NoaPrefs {
    const val FILE = "noa_prefs"
    const val KEY_SENSITIVITY = "sensitivity"       // Float 0..1
    const val KEY_PARTICLES = "particles"           // Boolean
    const val KEY_TRANSPARENT_MODE = "transparent_mode"
    const val KEY_TRANSPARENCY = "transparency"     // Float 0..1
    const val KEY_BLUR = "blur"                     // Float 0..1

    fun get(ctx: Context): SharedPreferences =
        ctx.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun sensitivity(ctx: Context) = get(ctx).getFloat(KEY_SENSITIVITY, 0.5f)
    fun particles(ctx: Context) = get(ctx).getBoolean(KEY_PARTICLES, true)

    fun readUi(ctx: Context): UiPrefs {
        val p = get(ctx); val d = UiPrefs()
        return UiPrefs(
            transparentMode = p.getBoolean(KEY_TRANSPARENT_MODE, d.transparentMode),
            transparency = p.getFloat(KEY_TRANSPARENCY, d.transparency),
            blur = p.getFloat(KEY_BLUR, d.blur)
        )
    }

    /** Emite um novo UiPrefs a cada mudança: a Home reage ao vivo enquanto você mexe nos sliders. */
    fun uiFlow(ctx: Context): Flow<UiPrefs> = callbackFlow {
        val prefs = get(ctx)
        val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> trySend(readUi(ctx)) }
        prefs.registerOnSharedPreferenceChangeListener(listener)
        trySend(readUi(ctx))
        awaitClose { prefs.unregisterOnSharedPreferenceChangeListener(listener) }
    }
}
