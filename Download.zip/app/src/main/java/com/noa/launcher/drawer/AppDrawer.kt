package com.noa.launcher.drawer

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.noa.launcher.settings.UiPrefs

/**
 * O blur do fundo NÃO é feito aqui: é aplicado na janela (HomeActivity.window.setBackgroundBlurRadius),
 * o que desfoca o wallpaper real atrás. Aqui só pintamos um véu translúcido por cima.
 */
@Composable
fun AppDrawer(
    apps: List<AppInfo>,
    query: String,
    ui: UiPrefs,
    onQuery: (String) -> Unit,
    onLaunch: (AppInfo) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = ui.glass(0.35f)))
            .statusBarsPadding()
            .padding(horizontal = 20.dp)
    ) {
        Spacer(Modifier.height(16.dp))

        // Campo de busca "glass"
        Box(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(Color.White.copy(alpha = ui.glass(0.10f)))
                .padding(horizontal = 18.dp, vertical = 14.dp)
        ) {
            if (query.isEmpty()) Text("Buscar", color = Color.White.copy(0.45f), fontSize = 16.sp, fontWeight = FontWeight.Light)
            BasicTextField(
                value = query,
                onValueChange = onQuery,
                singleLine = true,
                textStyle = TextStyle(color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Light),
                cursorBrush = SolidColor(Color.White),
                modifier = Modifier.fillMaxWidth()
            )
        }

        Spacer(Modifier.height(12.dp))

        LazyVerticalGrid(
            columns = GridCells.Fixed(4),
            contentPadding = PaddingValues(bottom = 32.dp + 48.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(apps, key = { it.component.flattenToString() }) { app ->
                Column(
                    Modifier.clickable { onLaunch(app) },
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Image(app.icon, app.label, Modifier.size(52.dp))
                    Spacer(Modifier.height(6.dp))
                    Text(
                        app.label, color = Color.White.copy(0.85f), fontSize = 11.sp,
                        fontWeight = FontWeight.Light, maxLines = 1,
                        overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
}
